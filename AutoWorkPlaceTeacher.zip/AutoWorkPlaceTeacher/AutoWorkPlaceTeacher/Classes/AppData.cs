﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoWorkPlaceTeacher.Classes
{
    internal class AppData
    {
        public static DataBase.AutWorkPlaceTeacherEntities Context { get; } = new DataBase.AutWorkPlaceTeacherEntities();
    }
}
