﻿using AutoWorkPlaceTeacher.MVVM.View;
using System;
using System.Windows;
using System.Windows.Controls;

namespace AutoWorkPlaceTeacher.Windows
{
    /// <summary>
    /// Логика взаимодействия для Home.xaml
    /// </summary>
    public partial class Home : Window
    {
        DataBase.Teacher userAuth = new DataBase.Teacher();
        public Home()
        {
            InitializeComponent();
        }
        public Home(DataBase.Teacher user)
        {
            InitializeComponent();

            userAuth = user;

            txtWelcomeUser.Text = "Здравствуйте, " + userAuth.LastName + " " + userAuth.FirstName + " " + userAuth.Patronymic +  "." + "\n" + "Авторизация прошла успешно";

        }
        
    }
}
