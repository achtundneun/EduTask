﻿using AutoWorkPlaceTeacher.Classes;
using AutoWorkPlaceTeacher.Windows;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoWorkPlaceTeacher.MVVM.View
{
    /// <summary>
    /// Логика взаимодействия для StudentListView.xaml
    /// </summary>
    public partial class StudentListView : UserControl
    {
        public StudentListView()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            StudentListGrid.ItemsSource = AppData.Context.Student.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog p = new PrintDialog();
            if (p.ShowDialog()== true)
            {
                p.PrintVisual(StudentListGrid, "Печать");
            }
        }
    }
}
