﻿using AutoWorkPlaceTeacher.Classes;
using AutoWorkPlaceTeacher.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoWorkPlaceTeacher.MVVM.ViewModel
{
    class MainViewModel : ObservableObject
    {
        public RelayCommand ProfileViewCommand { get; set; }
        public RelayCommand TimetableViewCommand { get; set; }
        public RelayCommand EventViewCommand { get; set; }
        public RelayCommand GroupListViewCommand { get; set; }
        public RelayCommand StudentListViewCommand { get; set; }
        public RelayCommand InformationViewCommand { get; set; }
        public ProfileViewModel ProfileVM { get; set; }
        public TimeTableViewModel TimeTableVM { get; set; }
        public EventViewModel EventVM { get; set; }
        public GroupListViewModel GroupListVM { get; set; }
        public StudentListViewModel StudentListVM { get; set; }
        public InformationViewModel InformationVM { get; set; }

        private object _currentView;

        public object CurrentView
        {
            get { return _currentView; }
            set 
            { 
                _currentView = value;
                OnPropertyChanged();
            }
        }
        public MainViewModel()
        {
            ProfileVM = new ProfileViewModel();
            TimeTableVM = new TimeTableViewModel();
            EventVM = new EventViewModel();
            GroupListVM = new GroupListViewModel();
            StudentListVM = new StudentListViewModel();
            InformationVM = new InformationViewModel();

            CurrentView = ProfileVM;

            ProfileViewCommand = new RelayCommand(o =>
            {
                CurrentView = ProfileVM;
            });

            TimetableViewCommand = new RelayCommand(o =>
            {
                CurrentView = TimeTableVM;
            });

            EventViewCommand = new RelayCommand(o =>
            {
                CurrentView = EventVM;
            });

            GroupListViewCommand = new RelayCommand(o =>
            {
                CurrentView = GroupListVM;
            });

            StudentListViewCommand = new RelayCommand(o =>
            {
                CurrentView = StudentListVM;
            });

            InformationViewCommand = new RelayCommand(o =>
            {
                CurrentView = InformationVM;
            });
        }
    }
}
